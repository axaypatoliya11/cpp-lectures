#include<iostream>

using namespace std;

int main(){

    int num;
    cout << "this is output.\n";
    cout << "enter a number: ";
    cin >> num;
    cout << "entered number is " << num << " and square of entered number is " << num*num << "\n";
    return 0;
}